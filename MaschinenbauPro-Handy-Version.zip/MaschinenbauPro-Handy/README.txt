MASCHINENBAU PRO – HANDY / OFFLINE VERSION

Diese Version ist als Progressive Web App (PWA) vorbereitet.

WICHTIG:
Der erste Aufruf muss online erfolgen, damit Chrome die externen Bibliotheken
(Tailwind, Font Awesome, Chart.js, Google Fonts und der Sound) laden und der
Service Worker sie zwischenspeichern kann. Danach kann die App bei erfolgreicher
Cache-Erstinstallation auch ohne Internet verwendet werden.

DATEIEN:
- index.html        = die eigentliche App
- manifest.webmanifest = Installationsdaten
- sw.js             = Offline-Cache
- icon.svg          = App-Symbol

Für die Installation auf Android muss die Datei online über HTTPS bereitgestellt
werden. Das einfache Öffnen einer lokalen HTML-Datei (file://) reicht für eine
installierbare PWA nicht aus.
